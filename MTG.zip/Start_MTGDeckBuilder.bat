@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0Logs" mkdir "%~dp0Logs"
set "LAUNCH_LOG=%~dp0Logs\Launcher.log"
echo [%date% %time%] Starting "%~dp0MTGDeckBuilder.ps1" >> "%LAUNCH_LOG%"
if not exist "%~dp0MTGDeckBuilder.ps1" (
  echo MTGDeckBuilder.ps1 is missing next to this launcher.
  echo [%date% %time%] ERROR: MTGDeckBuilder.ps1 missing >> "%LAUNCH_LOG%"
  pause
  exit /b 1
)
where pwsh.exe >nul 2>&1
if errorlevel 1 (
  echo PowerShell 7 ^(pwsh.exe^) is required. Install it with: winget install --id Microsoft.PowerShell --source winget
  echo [%date% %time%] ERROR: pwsh.exe missing >> "%LAUNCH_LOG%"
  pause
  exit /b 1
)
pwsh.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0MTGDeckBuilder.ps1" >> "%LAUNCH_LOG%" 2>&1
set "APP_EXIT=%errorlevel%"
echo [%date% %time%] App exited with code %APP_EXIT% >> "%LAUNCH_LOG%"
if not "%APP_EXIT%"=="0" (
  echo MTG Deck Builder stopped with code %APP_EXIT%.
  echo See "%LAUNCH_LOG%" and the other files in Logs.
  pause
)
exit /b %APP_EXIT%
